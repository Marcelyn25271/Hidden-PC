<meta http-equiv="acción" content="segundos"; url="url destino" />
