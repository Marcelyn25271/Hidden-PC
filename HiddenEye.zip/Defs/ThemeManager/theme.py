#
#    HiddenEye  Copyright (C) 2020  DarkSec https://dark-sec-official.com
#    This program comes with ABSOLUTELY NO WARRANTY; for details read LICENSE.
#    This is free software, and you are welcome to redistribute it
#    under certain conditions; you can read LICENSE for details.
#


default_palette = ['\033[91m', '\033[46m', '\033[36m', '\033[1;32m',  '\033[0m'] #Will be replaced later, TODO