#
#    HiddenEye  Copyright (C) 2020  DarkSec https://dark-sec-official.com
#    This program comes with ABSOLUTELY NO WARRANTY; for details read LICENSE.
#    This is free software, and you are welcome to redistribute it
#    under certain conditions; you can read LICENSE for details.
#



import gettext
gettext.bindtextdomain('HiddenEye', 'locale')
gettext.textdomain('HiddenEye')
_ = gettext.gettext